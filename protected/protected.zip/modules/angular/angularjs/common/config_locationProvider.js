
_PH__APP_NAME_.config(['$locationProvider', function($location) {
    $location.hashPrefix('!');
}]);
