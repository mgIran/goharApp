<ul>
    <li><a href="<?php echo $this->createUrl('index'); ?>">Example 1</a></li>
    <li><a href="<?php echo $this->createUrl('todoApp'); ?>">Example 2</a></li>
    <li><a href="<?php echo $this->createUrl('dontInclude'); ?>">Example 3</a></li>
</ul>

<hr />