<?
$this->menu = array(
    array('label'=>'مدیریت', 'url'=>array('admin')),
);
?>

<?php $this->renderPartial('_form', array('model'=>$model,'prefixes' => $prefixes)); ?>