<?php
/* @var $this FeedController */
/* @var $model Feed */


?>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>