<form id='filter-form'>
    <div id="search-box">
        <div id="search-text">
            <input id='full_name' type="text" name="name" class='back-white shady' placeholder="جستجو بر اساس نام پلن">
            <button type="submit" class="gray-button shady" id='search-users'><i class='fa fa-search'></i></button>
        </div>
    </div>
</form>