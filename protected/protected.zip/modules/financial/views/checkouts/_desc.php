<div class="factor-box-title">
    توضیحات فروشنده :
</div>
<div class="factor-sections factor-box col-md-12">
    تخفیف
</div>
<div class="factor-box-title">
    توضیحات خریدار :
</div>
<div class="factor-sections factor-box col-md-12 buyer">
    تخفیف
</div>