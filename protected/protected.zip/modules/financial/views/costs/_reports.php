<div class="col-md-6">
    <div class="plans-labels">
        <div class="col-md-12">
            <div class="factor-title">
                <span>
                گزارشات
                </span>
            </div>
            <div class="factor-sections col-md-12" style="color:#fff;">
                <!--<div class="row">
                    <div class="col-md-6">
                        تعداد ماه های آینده که در آن قسط داریم
                    </div>
                    <div class="col-md-6">
                        <?/*
                        Costs::model()->count('');
                        */?>
                    </div>
                </div>-->
            </div>
        </div>
        <div class="factor-final"></div>
    </div>
</div>