<div class="modal fade" id="confirm-delete-all" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="width: 350px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close pull-left" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">هشدار!</h4>
            </div>
            <div class="modal-body">
                <div class='row'>
                    آیا برای حذف موارد انتخابی مطمئن هستید؟ 
                </div>
                <div class='row'>
                    <div class="footer-buttons-area">
                        <button type="button" data-dismiss="modal" class="cms-button cancel-button left-margin-5">خیر</button>
                        <button type="button" class="cms-button ok-button submit delete-all-yes">بله</button>
                    </div>
                </div>                
            </div>            
        </div>
    </div>
</div>
