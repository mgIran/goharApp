<form id='filter-form'>
    <div id="search-box">
        <div id="search-text">
            <input id='title' type="text" name="title" class='back-white shady' placeholder="جستجو">
            <button type="submit" class="gray-button shady" id='search-usersroles'><i class='fa fa-search'></i></button>
        </div>      
    </div>
</form>