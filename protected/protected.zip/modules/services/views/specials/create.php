<?php

$this->renderPartial('/specials/_form', array('model'=>$model,'numbers'=>$numbers,'overallModel'=>$overallModel)); ?>